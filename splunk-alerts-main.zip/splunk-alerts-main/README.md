# splunk-alerts


![Screen Shot 1401-06-28 at 17 05 58](https://user-images.githubusercontent.com/25712816/191307597-589ff53d-a64a-4e93-bf24-df8414b3bdb0.png)
![Screen Shot 1401-06-28 at 17 06 40](https://user-images.githubusercontent.com/25712816/191307609-9a0dbf7c-b738-4d50-9335-050abb102d4a.png)
![Screen Shot 1401-06-28 at 17 07 00](https://user-images.githubusercontent.com/25712816/191307621-4b3ccec3-1cf0-4180-97bc-d214c20c1444.png)
