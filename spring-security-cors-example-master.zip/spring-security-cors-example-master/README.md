# spring-security-cors-example
How to enable cors policy for your rest api 

# CORS POLICY : ERRROR

	/*
	 * 'http://localhost:8080/access' from origin 'http://localhost:9090' has been
	 * blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on
	 * the requested resource.
	 */
