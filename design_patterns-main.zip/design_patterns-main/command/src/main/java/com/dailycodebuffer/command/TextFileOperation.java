package com.dailycodebuffer.command;

@FunctionalInterface
public interface TextFileOperation {
    String execute();
}
