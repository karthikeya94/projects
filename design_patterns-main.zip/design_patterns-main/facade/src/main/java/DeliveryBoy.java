public class DeliveryBoy {
    public void pickUpOrder() {

    }
    public void deliverOrder() {

    }
}
