public class DeliveryTeam {
    public void assignDeliveryBoy() {

    }
}
