public class Restaurant {
    public void prepareOrder() {

    }
}
