public class UHD4KProcessor implements VideoProcessor{
    @Override
    public void process(String videoFile) {
        //process
    }
}
