public interface VideoProcessor {
    void process(String videoFile);
}
