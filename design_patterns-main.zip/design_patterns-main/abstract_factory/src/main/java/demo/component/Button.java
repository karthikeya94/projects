package demo.component;

public interface Button {
    void paint();
}
