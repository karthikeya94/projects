package com.dailycodebuffer.observer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
