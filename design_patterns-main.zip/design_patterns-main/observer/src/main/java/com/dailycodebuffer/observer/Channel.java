package com.dailycodebuffer.observer;

public interface Channel {
    public void update(Object o);
}
