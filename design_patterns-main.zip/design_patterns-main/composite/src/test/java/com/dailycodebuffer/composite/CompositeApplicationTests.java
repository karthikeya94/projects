package com.dailycodebuffer.composite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompositeApplicationTests {

	@Test
	void contextLoads() {
	}

}
