public class FoodItem implements Item{
    @Override
    public String getItemName() {
        return null;
    }

    @Override
    public String getPrice() {
        return null;
    }

    @Override
    public String getRestaurantName() {
        return null;
    }
}
