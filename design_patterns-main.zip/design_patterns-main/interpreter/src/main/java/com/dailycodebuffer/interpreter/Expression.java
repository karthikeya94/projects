package com.dailycodebuffer.interpreter;

public interface Expression {
    public boolean interpret(String context);
}
