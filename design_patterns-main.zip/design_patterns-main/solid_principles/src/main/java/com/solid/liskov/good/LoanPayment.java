package com.solid.liskov.good;

public interface LoanPayment {
    public void doPayment(int amount);
}
