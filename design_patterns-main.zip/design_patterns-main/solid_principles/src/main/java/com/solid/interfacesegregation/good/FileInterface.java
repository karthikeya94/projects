package com.solid.interfacesegregation.good;

public interface FileInterface {
    public void openFile();
}
