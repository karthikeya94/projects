package com.solid.interfacesegregation.good;

public interface DBInterface {
    public void openConnection();
}
