package com.dailycodebuffer.flyweight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlyweightApplicationTests {

    @Test
    void contextLoads() {
    }

}
