public class BankAccount implements  Account{
    @Override
    public void withdraw() {

    }

    @Override
    public void getAccountNumber() {

    }
}
