package com.javatechie.reactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RexceptionHandlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
