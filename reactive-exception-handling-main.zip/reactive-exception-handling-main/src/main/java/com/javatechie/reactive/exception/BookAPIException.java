package com.javatechie.reactive.exception;

public class BookAPIException extends Exception{

    public BookAPIException(String message) {
        super(message);
    }
}
