package com.javatechie.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RexceptionHandlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RexceptionHandlerApplication.class, args);
	}

}
