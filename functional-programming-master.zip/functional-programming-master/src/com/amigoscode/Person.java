package com.amigoscode;

public record Person(
        String name,
        String phoneNumber,
        String email) {
}
