def containsX(string):
  for char in string:
    if char == "X":
      return True

  return False