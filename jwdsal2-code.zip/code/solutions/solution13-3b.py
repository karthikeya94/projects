def max(array):
  array.sort()

  return array[-1]