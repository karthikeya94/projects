# docker-jenkins-integration-sample

###### Docker [Playlist](https://www.youtube.com/watch?v=Tg2krHXHzBc&list=PLVz2XdJiJQxzMiFDnwxUDxmuZQU3igcBb).
###### Jenkins [Playlist](https://www.youtube.com/watch?v=Nw3UohhcPO0&list=PLVz2XdJiJQxwS0BZUHX34ocLTJtRGSQzN).
