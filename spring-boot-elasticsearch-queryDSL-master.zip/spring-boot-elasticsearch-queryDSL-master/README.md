# spring-boot-elasticsearch-queryDSL
Spring data elastic search using query DSL
