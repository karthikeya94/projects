package com.javatechie.pm.api.util;

public class NotificationUtil {
	
	
	public static String sendEmail(String email) {
		//use mail API 
		return "success";
	}

}
