package com.dailycodebuffer.cabbookdriver.constant;

public class AppConstant {
    public static final String CAB_LOCATION = "cab-location";
}
