package com.dailycodebuffer.cabbookdriver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabBookDriverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabBookDriverApplication.class, args);
	}

}
