package com.dailycodebuffer.cabbookuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabBookUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabBookUserApplication.class, args);
	}

}
