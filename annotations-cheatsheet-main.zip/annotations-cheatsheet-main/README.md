# annotations-cheatsheet

# Spring, Spring Boot Annotations Cheat sheet

### Spring Boot Main annotations 
- @SpringBootApplication
- @ComponentScan
- @EanbleAutoConfiguration
- @Configuration

### Stereotype annotation 
- @Component
- @Controller
- @Service
- @Repository
