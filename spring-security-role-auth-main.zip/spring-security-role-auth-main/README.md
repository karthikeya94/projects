# spring-security-role-auth
Implement Role base authorization (Facebook Group Example)
