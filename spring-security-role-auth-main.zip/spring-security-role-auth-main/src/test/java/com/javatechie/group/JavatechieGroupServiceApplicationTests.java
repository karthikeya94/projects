package com.javatechie.group;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavatechieGroupServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
