package com.javatechie.group.entity;

public enum PostStatus {

    PENDING,APPROVED,REJECTED;
}
