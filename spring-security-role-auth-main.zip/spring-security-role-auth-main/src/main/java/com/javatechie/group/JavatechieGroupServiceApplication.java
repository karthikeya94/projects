package com.javatechie.group;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavatechieGroupServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavatechieGroupServiceApplication.class, args);
	}

}
