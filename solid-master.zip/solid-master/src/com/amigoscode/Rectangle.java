package com.amigoscode;

public class Rectangle implements Shape {
    @Override
    public double area() {
        return 20;
    }
}
