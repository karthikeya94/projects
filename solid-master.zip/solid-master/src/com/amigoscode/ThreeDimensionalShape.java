package com.amigoscode;

public interface ThreeDimensionalShape {
    double volume();
}
