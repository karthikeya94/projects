package com.amigoscode;

public interface Shape {
    double area();
}
