package com.javatechie.service;

import org.springframework.stereotype.Component;

//@Component
public class DemoService {
}
