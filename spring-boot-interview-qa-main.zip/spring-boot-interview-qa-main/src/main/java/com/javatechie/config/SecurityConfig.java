package com.javatechie.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {

    public SecurityConfig() {
        System.out.println("SecurityConfig loaded .....");
    }
}
