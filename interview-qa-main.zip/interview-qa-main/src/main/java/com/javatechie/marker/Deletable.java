package com.javatechie.marker;

public interface Deletable {
}
