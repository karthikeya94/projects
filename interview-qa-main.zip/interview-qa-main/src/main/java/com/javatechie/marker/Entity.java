package com.javatechie.marker;

public class Entity implements Deletable{

    //attributes
}
