package com.javatechie.spring.exp.handle.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringExceptionHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringExceptionHandlingApplication.class, args);
	}
}
