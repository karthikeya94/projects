# spring-exception-handling
How to handle Exception in spring Rest 
