# spring-boot-elasticsearch-example
How to start SpringBoot ElasticSearch using Spring Data
