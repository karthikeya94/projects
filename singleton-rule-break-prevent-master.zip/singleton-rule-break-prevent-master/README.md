# singleton-rule-break-prevent
What are the various way to break singleton behavior and how we can protect them 
