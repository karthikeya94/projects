package com.javatechie.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class EmailConfig {
}
