package com.javatechie.service;

import com.javatechie.entity.Employee;

public interface EmployeeService extends GenericService<Employee, Integer> {
}